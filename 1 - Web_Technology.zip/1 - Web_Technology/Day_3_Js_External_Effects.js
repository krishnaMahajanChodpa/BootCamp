function demoExtrenalAlert()
{
    alert("Krishna Mahajan");
}
function demoExternalConfirm()
{
    if(confirm("Are You Fine Friend...??"))
    {
        alert("Ok..Thanks...");
    }
    else
    {
        alert("Ooppss...Please Take Care");
    }
}
function demoExternalPrompt()
{
        var sId=prompt("Enter Your Id ==>> ");

       if(sId==20094)
        {
            alert("Vishnu Mehendalekar , Chalisgaon");
        }
        else if(sId==20078)
        {
            alert("Krishna Mahajan , Chopda");

        }
        else if(sId==20060)
        {
            alert("Hansla mansuri , Ahmedabad");
        }
}