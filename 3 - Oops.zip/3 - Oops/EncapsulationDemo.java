import java.io.*;

class Employee
{
	String name,role,contact;
	int age;

	void setName(String sName)
	{
		name=sName;
	}
	String getName()
	{
		return name;
	}

	void setRole(String sRole)
	{
		role=sRole;
	}
	String getRole()
	{
		return role;
	}

	void setContact(String sContact)
	{
		contact=sContact;
	}
	String getContact()
	{
		return contact;
	}

	void setAge(int sAge)
	{
		age=sAge;
	}
	int getAge()
	{
		return age;
	}
	public void show()
	{
		System.out.println("\n\n\t\t\t\tEmployee Name is ==>> "+name);
		System.out.println("\t\t\t\tEmployee Contact is ==>> "+contact);
		System.out.println("\t\t\t\tEmployee Age is ==>> "+age);
		System.out.println("\t\t\t\tEmployee Role is ==>> "+role);
	}
}
class EncapsulationDemo
{
	public static void main(String args[])
	{
		System.out.println("\n\t\t*************** Welcome KCS (Krish Compusoft Services) ***************");
		System.out.println("\n\t\t\t*************** Employee List Of KCS ***************");

		Employee e=new Employee();
		e.setName("Krishna Mahajan");
		e.setContact("9767667602");
		e.setRole("Java Developer");
		e.setAge(24);
		e.show();

		e.setName("Vishnu Mahendalekar");
		e.setContact("7721812333");
		e.setRole("Angular Developer");
		e.setAge(23);
		e.show();

		e.setName("Shubham Chaudhari");
		e.setContact("7752522352");
		e.setRole("React Developer");
		e.setAge(23);
		e.show();

		e.setName("Chetan Chitte");
		e.setContact("7798987798");
		e.setRole("Python Developer");
		e.setAge(29);
		e.show();
		System.out.println("\n\t\t************************************************************************");

	}
}