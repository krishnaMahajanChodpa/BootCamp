import java.io.*;

interface InterfaceOne
{
	public void show();
}
class child_One implements InterfaceOne
{
	public void show()
	{
		System.out.println("\n\t***************** Child One Class ******************");
		System.out.println("\tThis is Child One class Of Interface");
	}

}
class child_Two implements InterfaceOne
{
	public void show()
	{
		System.out.println("\n\t***************** Child Two Class ******************");
		System.out.println("\tThis is Child Two class Of Interface");
	}

}
class Method_injection
{
	InterfaceOne I1;
	public Method_injection(InterfaceOne II)
	{
		this.I1=II;
		I1.show();
	}
}
class MethodInectionDemo  //this class for just main Methos
{
	public static void main(String args[])
	{
		System.out.println("\n\t***************** Method Inejction ******************");
		Method_injection MI=new Method_injection(new child_One());
		MI=new Method_injection(new child_Two());

		System.out.println("\n\t*****************************************************");
	}
}