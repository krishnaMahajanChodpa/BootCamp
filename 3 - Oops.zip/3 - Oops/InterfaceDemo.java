import java.io.*;

interface Kcs
{
	public void staff();
	public void employee();
}
class child implements Kcs
{
	public void staff()
	{
		System.out.println("\n********************* Staff ***********************");


		System.out.println("\n\t      Head       :: Satnadu Nayadu Sir");
		System.out.println("\t      Hr         :: Heena Mam");
		System.out.println("\t      Hr         :: Jeet Sir");
		System.out.println("\t      Management :: Komal Mam");
		System.out.println("\t      Trainer    :: Abhishek Pujara Sir");
	}

	public void employee()
	{
		System.out.println("\n********************* Employee ***********************");


		System.out.println("\n\t    Name       ::  Krishna Mahajan");
		System.out.println("\t    Contact    ::  9767667602");
		System.out.println("\t    Age        ::  24");
		System.out.println("\t    City       ::  Jalgaon");
		System.out.println("\t    Role       ::  Java Developer");

	}

}
class child2 implements Kcs
{
		public void staff()
		{

		}
		public void employee()
		{
				System.out.println("\n\t    Name       :: Jaydeep Advani ");
				System.out.println("\t    Contact    ::  9033456527");
				System.out.println("\t    Age        ::  23");
				System.out.println("\t    City       ::  BhavNagar");
				System.out.println("\t    Role       ::  Android Developer");
		}

}
class InterfaceDemo
{
	public static void main(String args[])
	{
		System.out.println("\n********************* INTERFACE ***********************");

		Kcs k=new child();
		k.staff();
		k.employee();

		Kcs refk=new child2();
		refk.employee();

		System.out.println("\n******************************************************");
	}

}