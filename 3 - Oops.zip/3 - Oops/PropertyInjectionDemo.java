import java.io.*;

interface InterfaceOne
{
	public void show(String s);
}
class child_one implements InterfaceOne
{
	public void show(String s)
	{
		System.out.println("\n\t***************** Child One Class ******************");
		System.out.println("\tThis is child one class of Interface :"+s);
	}
}
class child_two implements InterfaceOne
{
	public void show(String s)
	{
		System.out.println("\n\t***************** Child Two Class ******************");
		System.out.println("\tThis is child Two class of Interface :"+s);
	}
}
class Property_Injection
{
	InterfaceOne I1;
	public Property_Injection(InterfaceOne II , String s)
	{
		this.I1=II;
		I1.show(s);
	}
}
class PropertyInjectionDemo
{
	public static void main(String args[])
	{
		System.out.println("\n\t***************** Property Inejction ******************");

		Property_Injection PI=null;
		PI=new Property_Injection(new child_one(), "Krishna");
		PI=new Property_Injection(new child_two(), "Mahajan");

		System.out.println("\n\t*****************************************************");

	}

}