import java.io.*;

class parent
{
	void parentShowMethod()
	{
		System.out.println("\n\tThis is Parent Show Method");
	}
}
class child extends parent
{
	void childShowMethod()
	{
		System.out.println("\tThis is Child Show Methos");
	}
}

class InheritanceDemo
{
	public static void main(String args[])
	{
		System.out.println("\n*************** Inheritance Consept **************");
		child c=new child();
		c.parentShowMethod();
		c.childShowMethod();
		System.out.println("\n**************************************************");
	}

}