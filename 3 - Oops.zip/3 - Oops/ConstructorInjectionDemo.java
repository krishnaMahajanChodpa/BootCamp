import java.io.*;

interface InterfaceOne
{
	public void show();
}
class child_one implements InterfaceOne
{
	public void show()
	{
		System.out.println("\n\t*********** Child One Method Call ***********");
		System.out.println("\tThis is Child One class of Interface");
	}
}
class child_two implements InterfaceOne
{
	public void show()
	{
		System.out.println("\n\t*********** Child Two Method Call ***********");
		System.out.println("\tThis is Child two class of Interface");
	}
}
class CunstructorInjection
{
	InterfaceOne I1;

	public CunstructorInjection(InterfaceOne I1)
	{
		this.I1=I1;
	}

	public void show()
	{
		I1.show();
	}
}


class ConstructorInjectionDemo //this class for just main Methos
{

	public static void main(String args[])
	{
		System.out.println("\n\t*********** Constructor Injection ***********");
		CunstructorInjection cn=null;
		cn=new CunstructorInjection(new child_one());
		cn.show();

		cn=new CunstructorInjection(new child_two());
		cn.show();

		System.out.println("\n\t*********************************************");
	}

}