import java.io.*;

class parent
{
	void show()
	{
		System.out.println("\nThis is show Method Parent class");
	}

	void display()
	{
		System.out.println("\nw Without Parametar");
	}

	void display(int a)
	{
		System.out.println("Single Parametar : "+a);
	}

	void display(int a , String b)
	{
		System.out.println("Double Parametar : "+a +"   " +b);
	}

}
class child extends parent
{
	void show()
	{
		System.out.println("This is show method of child class");
	}
}
class polyProgram
{
	public static void main(String args[])
	{
		System.out.println(" ********** This is Function Overriding **********");
		parent p=new parent();
		p.show();

		child c=new child();
		c.show();

		System.out.println(" \n********** This is Function Loading **********");

		parent ovrlp=new parent();
		ovrlp.display();
		ovrlp.display(10);
		ovrlp.display(24, "Krishna");

		System.out.println(" \n**********    ********************     **********");

	}
}

