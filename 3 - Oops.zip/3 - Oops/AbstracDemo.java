import java.io.*;

abstract class demo
{
	public abstract void show();
}
class child extends demo
{
	public void show()
	{
		System.out.println("\n\n Abstract Methos ");
	}
}
class AbstracDemo
{
	public static void main(String args[])
	{
		child c=new child();
		c.show();
	}

}